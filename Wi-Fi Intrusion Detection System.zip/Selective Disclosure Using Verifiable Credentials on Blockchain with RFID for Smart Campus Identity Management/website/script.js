document.addEventListener('DOMContentLoaded', () => {
    const navbar = document.getElementById('navbar');
    const navToggle = document.getElementById('navToggle');
    const navLinks = document.getElementById('navLinks');
    const navItems = document.querySelectorAll('.nav-links a');
  
    // Navbar scroll effect
    window.addEventListener('scroll', () => {
      if (window.scrollY > 50) {
        navbar.style.boxShadow = '0 4px 6px -1px rgba(0,0,0,0.1)';
        navbar.style.padding = '10px 0';
      } else {
        navbar.style.boxShadow = '0 2px 4px rgba(0,0,0,0.05)';
        navbar.style.padding = '0'; // The container has the padding
      }
    });
  
    // Mobile menu toggle
    navToggle.addEventListener('click', () => {
      navLinks.classList.toggle('active');
    });
  
    // Close mobile menu on click
    navItems.forEach(item => {
      item.addEventListener('click', () => {
        if (navLinks.classList.contains('active')) {
          navLinks.classList.remove('active');
        }
      });
    });
  
    // Simple scroll reveal (adds class when element is in viewport)
    const revealElements = document.querySelectorAll('.card, .section-header');
    
    const revealOptions = {
      threshold: 0.15,
      rootMargin: "0px 0px -50px 0px"
    };
  
    const revealOnScroll = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        
        // Add a subtle fade-in class if we defined one in CSS
        entry.target.style.opacity = "1";
        entry.target.style.transform = "translateY(0)";
        
        observer.unobserve(entry.target);
      });
    }, revealOptions);
  
    revealElements.forEach(el => {
      // Set initial state for reveal
      el.style.opacity = "0";
      el.style.transform = "translateY(20px)";
      el.style.transition = "opacity 0.6s ease-out, transform 0.6s ease-out";
      
      revealOnScroll.observe(el);
    });
  });
