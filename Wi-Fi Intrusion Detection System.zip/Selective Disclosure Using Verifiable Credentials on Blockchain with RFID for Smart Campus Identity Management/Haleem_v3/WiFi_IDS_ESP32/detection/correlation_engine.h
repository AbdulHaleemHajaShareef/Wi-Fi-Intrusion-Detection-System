
#ifndef CORRELATION_ENGINE_H
#define CORRELATION_ENGINE_H

#include <Arduino.h>
#include "../utils/event_log.h"

// Time window: if Deauth + Rogue AP both seen within this period → COORDINATED attack
#define CORRELATION_WINDOW_MS  15000   // 15 seconds
#define CORR_COOLDOWN_MS       20000   // minimum gap between two correlation alerts
#define CORR_HISTORY_SIZE      8       // recent events to track

void correlation_engine_init();

// Call AFTER deauth_detector_process() and rogue_ap_detector_process()
// in on_packet() — it reads the newest event_log entry each time
void correlation_engine_update();

#endif // CORRELATION_ENGINE_H
