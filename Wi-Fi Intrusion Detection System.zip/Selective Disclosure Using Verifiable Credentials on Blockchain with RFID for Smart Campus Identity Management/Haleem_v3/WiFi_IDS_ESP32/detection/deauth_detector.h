
#ifndef DEAUTH_DETECTOR_H
#define DEAUTH_DETECTOR_H

#include <Arduino.h>
#include "../sniffer/sniffer.h"
#include "../utils/event_log.h"

// ─────────────────────────────────────────
//  Tunable thresholds
// ─────────────────────────────────────────
#define DEAUTH_TIME_WINDOW_MS   5000   // rolling window in ms
#define DEAUTH_LOW_THRESHOLD    5      // packets in window → LOW
#define DEAUTH_MEDIUM_THRESHOLD 15     // → MEDIUM
#define DEAUTH_HIGH_THRESHOLD   30     // → HIGH
#define DEAUTH_CRITICAL_THRESHOLD 60   // targeted burst → CRITICAL
#define DEAUTH_MAX_TRACKED_MACS 20     // max unique source MACs tracked

void deauth_detector_init();
void deauth_detector_process(const packet_info_t *pkt);
void deauth_detector_tick();  // Call in loop() to expire old entries

#endif
