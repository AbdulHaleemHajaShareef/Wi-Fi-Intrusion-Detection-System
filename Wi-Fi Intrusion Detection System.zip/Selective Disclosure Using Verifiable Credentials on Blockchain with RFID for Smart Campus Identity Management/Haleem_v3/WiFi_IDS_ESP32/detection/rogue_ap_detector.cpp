
#include "rogue_ap_detector.h"

// ─────────────────────────────────────────
//  Known AP record
// ─────────────────────────────────────────
typedef struct {
    char    ssid[33];
    uint8_t bssid[6];    // First-seen BSSID for this SSID
    int8_t  rssi;
    bool    active;
} ap_entry_t;

static ap_entry_t _aps[MAX_KNOWN_APS];

// ─────────────────────────────────────────
//  Find existing SSID entry
// ─────────────────────────────────────────
static ap_entry_t* find_ssid(const char *ssid) {
    for (int i = 0; i < MAX_KNOWN_APS; i++) {
        if (_aps[i].active && strcmp(_aps[i].ssid, ssid) == 0)
            return &_aps[i];
    }
    return nullptr;
}

static ap_entry_t* alloc_slot() {
    for (int i = 0; i < MAX_KNOWN_APS; i++) {
        if (!_aps[i].active) return &_aps[i];
    }
    return nullptr;  // table full
}

// ─────────────────────────────────────────
//  Public
// ─────────────────────────────────────────
void rogue_ap_detector_init() {
    memset(_aps, 0, sizeof(_aps));
    Serial.println("[ROGUE_AP] Detector initialized.");
}

void rogue_ap_detector_process(const packet_info_t *pkt) {
    // Only Beacon frames carry SSID
    if (pkt->frame_type    != FRAME_TYPE_MGMT)          return;
    if (pkt->frame_subtype != FRAME_SUBTYPE_BEACON)     return;
    if (!pkt->has_ssid || strlen(pkt->ssid) == 0)       return;

    ap_entry_t *entry = find_ssid(pkt->ssid);

    if (!entry) {
        // First time we see this SSID — register it
        ap_entry_t *slot = alloc_slot();
        if (!slot) return;
        strncpy(slot->ssid, pkt->ssid, 32);
        slot->ssid[32] = '\0';
        memcpy(slot->bssid, pkt->bssid, 6);
        slot->rssi   = pkt->rssi;
        slot->active = true;
        return;
    }

    // SSID already known — check if BSSID is different (Evil Twin)
    if (memcmp(entry->bssid, pkt->bssid, 6) != 0) {
        // Different BSSID with same SSID → possible Evil Twin
        // Severity: HIGH if rogue is stronger, MEDIUM otherwise
        severity_t sev = (pkt->rssi > entry->rssi) ? SEV_HIGH : SEV_MEDIUM;

        char details[80];
        char orig_mac[18], rogue_mac[18];
        mac_to_str(entry->bssid, orig_mac);
        mac_to_str(pkt->bssid,   rogue_mac);
        snprintf(details, sizeof(details),
                 "SSID='%s' orig=%s(%ddBm) rogue=%s(%ddBm)",
                 pkt->ssid, orig_mac, entry->rssi, rogue_mac, pkt->rssi);

        event_log_add(ATK_ROGUE_AP, sev, pkt->bssid, details);
    } else {
        // Same AP — update RSSI (moving towards rogue detection if it changes dramatically)
        entry->rssi = pkt->rssi;
    }
}
