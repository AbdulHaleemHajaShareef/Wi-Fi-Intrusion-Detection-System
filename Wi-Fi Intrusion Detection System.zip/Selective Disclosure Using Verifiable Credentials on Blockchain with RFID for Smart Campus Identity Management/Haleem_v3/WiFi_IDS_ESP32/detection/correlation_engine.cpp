
/*
 * correlation_engine.cpp
 *
 * CORE INNOVATION — detects ATTACK CHAINS by correlating independent
 * detection events over time:
 *
 *   Deauth Flood ──┐
 *                  ├── within CORRELATION_WINDOW_MS ──► COORDINATED ATTACK
 *   Rogue AP    ──┘
 *
 * How it works (no heap allocation):
 * - Watches the event_log for new entries by comparing event count.
 * - Maintains a small local ring buffer of recent {type, timestamp}.
 * - On each new event, scans for a matching Deauth+RogueAP pair.
 * - If found → logs ATK_COORDINATED with CRITICAL severity (once per cooldown).
 */

#include "correlation_engine.h"
#include "../utils/event_log.h"

// ─────────────────────────────────────────────
//  Local ring buffer of recently observed events
// ─────────────────────────────────────────────
typedef struct {
    attack_type_t type;
    uint32_t      timestamp_ms;
    char          src_mac[18];
    char          detail[48];   // SSID or short info
} corr_entry_t;

static corr_entry_t _history[CORR_HISTORY_SIZE];
static int          _h_head  = 0;
static int          _h_count = 0;

// Snapshot of event_log size last time we checked — detect new entries
static int          _last_seen_count = 0;
// Cooldown: don't fire more than once per CORR_COOLDOWN_MS
static uint32_t     _last_fire_ms    = 0;
static bool         _fired_once      = false;

// ─────────────────────────────────────────────
//  Private: push a new entry to the local history
// ─────────────────────────────────────────────
static void push_history(const event_record_t *ev) {
    corr_entry_t *slot = &_history[_h_head];
    slot->type         = ev->attack_type;
    slot->timestamp_ms = ev->timestamp_ms;
    strncpy(slot->src_mac, ev->src_mac, 17);
    slot->src_mac[17] = '\0';
    // Copy first 47 chars of details as a short label
    strncpy(slot->detail, ev->details, 47);
    slot->detail[47] = '\0';

    _h_head = (_h_head + 1) % CORR_HISTORY_SIZE;
    if (_h_count < CORR_HISTORY_SIZE) _h_count++;
}

// ─────────────────────────────────────────────
//  Private: scan history for a Deauth + Rogue pair within window
//  Returns true if pattern found; fills out_deauth / out_rogue
// ─────────────────────────────────────────────
static bool find_chain(corr_entry_t **out_deauth, corr_entry_t **out_rogue) {
    uint32_t now = millis();
    *out_deauth = nullptr;
    *out_rogue  = nullptr;

    // Scan all valid entries
    for (int i = 0; i < _h_count; i++) {
        int idx = (_h_head - 1 - i + CORR_HISTORY_SIZE) % CORR_HISTORY_SIZE;
        corr_entry_t *e = &_history[idx];

        // Ignore entries older than the window
        if ((now - e->timestamp_ms) > CORRELATION_WINDOW_MS) continue;

        if (e->type == ATK_DEAUTH   && *out_deauth == nullptr) *out_deauth = e;
        if (e->type == ATK_ROGUE_AP && *out_rogue  == nullptr) *out_rogue  = e;

        if (*out_deauth && *out_rogue) return true;
    }
    return false;
}

// ─────────────────────────────────────────────
//  Public API
// ─────────────────────────────────────────────
void correlation_engine_init() {
    memset(_history, 0, sizeof(_history));
    _h_head           = 0;
    _h_count          = 0;
    _last_seen_count  = 0;
    _last_fire_ms     = 0;
    _fired_once       = false;
    Serial.println("[CORR] Correlation engine initialized.");
}

void correlation_engine_update() {
    int current_count = event_log_count();
    if (current_count <= _last_seen_count) return;  // no new events

    // Ingest every new event since last check
    for (int i = _last_seen_count; i < current_count; i++) {
        const event_record_t *ev = event_log_get(i);
        if (!ev || !ev->valid) continue;
        // Only track primary attack types, not our own coordinated events
        if (ev->attack_type == ATK_COORDINATED) continue;
        push_history(ev);
    }
    _last_seen_count = current_count;

    // Check cooldown
    uint32_t now = millis();
    if (_fired_once && (now - _last_fire_ms) < CORR_COOLDOWN_MS) return;

    // Look for Deauth + Rogue AP within the window
    corr_entry_t *deauth_ev = nullptr;
    corr_entry_t *rogue_ev  = nullptr;

    if (!find_chain(&deauth_ev, &rogue_ev)) return;

    // ── Pattern found → fire COORDINATED alert ──
    _last_fire_ms = now;
    _fired_once   = true;

    char details[80];
    snprintf(details, sizeof(details),
             "Evil Twin Chain: Deauth(%s) + RogueAP(%s) in %lus window",
             deauth_ev->src_mac,
             rogue_ev->src_mac,
             (unsigned long)(CORRELATION_WINDOW_MS / 1000));

    // Use rogue AP's MAC as the "source" — it's the attacker's AP
    uint8_t rogue_mac_bytes[6] = {0};
    sscanf(rogue_ev->src_mac,
           "%02hhX:%02hhX:%02hhX:%02hhX:%02hhX:%02hhX",
           &rogue_mac_bytes[0], &rogue_mac_bytes[1], &rogue_mac_bytes[2],
           &rogue_mac_bytes[3], &rogue_mac_bytes[4], &rogue_mac_bytes[5]);

    event_log_add(ATK_COORDINATED, SEV_CRITICAL, rogue_mac_bytes, details);

    Serial.println("[CORR] *** COORDINATED ATTACK CHAIN DETECTED ***");
}
