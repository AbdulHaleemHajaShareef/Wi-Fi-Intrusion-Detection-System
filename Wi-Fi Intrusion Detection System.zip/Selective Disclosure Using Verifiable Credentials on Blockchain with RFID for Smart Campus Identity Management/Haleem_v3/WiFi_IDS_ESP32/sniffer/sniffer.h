
#ifndef SNIFFER_H
#define SNIFFER_H

#include <Arduino.h>
#include "esp_wifi.h"

// ─────────────────────────────────────────────
//  802.11 Frame Type / Subtype Constants
// ─────────────────────────────────────────────
#define FRAME_TYPE_MGMT       0x00
#define FRAME_SUBTYPE_DEAUTH  0x0C   // Deauthentication frame
#define FRAME_SUBTYPE_BEACON  0x08   // Beacon frame
#define FRAME_SUBTYPE_PROBE_REQ 0x04 // Probe Request
#define FRAME_SUBTYPE_PROBE_RES 0x05 // Probe Response
#define FRAME_SUBTYPE_ASSOC_REQ 0x00 // Association Request (mgmt)
#define FRAME_SUBTYPE_AUTH    0x0B   // Authentication

// ─────────────────────────────────────────────
//  Raw 802.11 Management Frame Header
//  (matches promiscuous payload layout)
// ─────────────────────────────────────────────
typedef struct {
    uint8_t  frame_ctrl[2];   // Frame Control field (type/subtype embedded)
    uint16_t duration;
    uint8_t  addr1[6];        // Destination MAC
    uint8_t  addr2[6];        // Source MAC (transmitter)
    uint8_t  addr3[6];        // BSSID
    uint16_t seq_ctrl;
} wifi_mgmt_hdr_t;

// ─────────────────────────────────────────────
//  Parsed packet record passed to detection
// ─────────────────────────────────────────────
typedef struct {
    uint8_t  frame_type;       // 0=Mgmt, 1=Ctrl, 2=Data
    uint8_t  frame_subtype;
    uint8_t  src_mac[6];
    uint8_t  dst_mac[6];
    uint8_t  bssid[6];
    int8_t   rssi;
    char     ssid[33];         // Only valid for Beacon / Probe frames
    bool     has_ssid;
    uint32_t timestamp_ms;
} packet_info_t;

// ─────────────────────────────────────────────
//  Public API
// ─────────────────────────────────────────────
void sniffer_init(uint8_t channel);          // Start promiscuous sniffer
void sniffer_set_channel(uint8_t channel);   // Hot-switch channel
void sniffer_stop();                         // Stop promiscuous mode
uint32_t sniffer_get_packet_count();         // Total packets seen

// Callback type — detection modules register here
typedef void (*packet_handler_t)(const packet_info_t *pkt);
void sniffer_register_handler(packet_handler_t handler);

#endif // SNIFFER_H
