
#include "sniffer.h"
#include "esp_wifi.h"
#include "esp_system.h"

// ─────────────────────────────────────────────
//  Module-private state
// ─────────────────────────────────────────────
static uint32_t            _packet_count  = 0;
static packet_handler_t    _user_handler  = nullptr;
static uint8_t             _channel       = 1;

// ─────────────────────────────────────────────
//  Helper: MAC bytes → readable string
// ─────────────────────────────────────────────
void mac_to_str(const uint8_t *mac, char *out) {
    sprintf(out, "%02X:%02X:%02X:%02X:%02X:%02X",
            mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
}

// ─────────────────────────────────────────────
//  Helper: extract SSID from Beacon / Probe body
//  body_start points to the first tagged parameter
// ─────────────────────────────────────────────
static void extract_ssid(const uint8_t *body, int body_len, char *ssid_out, bool *found) {
    *found = false;
    ssid_out[0] = '\0';
    int i = 0;
    while (i + 1 < body_len) {
        uint8_t tag_id  = body[i];
        uint8_t tag_len = body[i + 1];
        if (tag_id == 0 && tag_len > 0 && tag_len <= 32) {  // SSID element ID = 0
            memcpy(ssid_out, &body[i + 2], tag_len);
            ssid_out[tag_len] = '\0';
            *found = true;
            return;
        }
        i += 2 + tag_len;
    }
}

// ─────────────────────────────────────────────
//  Core promiscuous callback — called by esp-idf
//  for EVERY captured frame
// ─────────────────────────────────────────────
static void IRAM_ATTR promiscuous_rx_cb(void *buf, wifi_promiscuous_pkt_type_t type) {
    if (type != WIFI_PKT_MGMT && type != WIFI_PKT_DATA && type != WIFI_PKT_CTRL) return;

    const wifi_promiscuous_pkt_t *ppkt = (wifi_promiscuous_pkt_t *)buf;
    const uint8_t *payload = ppkt->payload;
    int payload_len = ppkt->rx_ctrl.sig_len;

    if (payload_len < (int)sizeof(wifi_mgmt_hdr_t)) return;  // too short

    _packet_count++;

    // ── Parse frame control ──
    uint8_t fc0 = payload[0];  // frame control byte 0
    uint8_t fc1 = payload[1];  // frame control byte 1
    uint8_t frame_type    = (fc0 & 0x0C) >> 2;  // bits 3-2
    uint8_t frame_subtype = (fc0 & 0xF0) >> 4;  // bits 7-4

    // ── Build packet_info_t ──
    packet_info_t pkt;
    memset(&pkt, 0, sizeof(pkt));

    pkt.frame_type    = frame_type;
    pkt.frame_subtype = frame_subtype;
    pkt.rssi          = ppkt->rx_ctrl.rssi;
    pkt.timestamp_ms  = millis();

    const wifi_mgmt_hdr_t *hdr = (wifi_mgmt_hdr_t *)payload;
    memcpy(pkt.dst_mac, hdr->addr1, 6);
    memcpy(pkt.src_mac, hdr->addr2, 6);
    memcpy(pkt.bssid,   hdr->addr3, 6);

    // ── Extract SSID for Beacon / Probe Response frames ──
    bool is_beacon    = (frame_type == FRAME_TYPE_MGMT && frame_subtype == FRAME_SUBTYPE_BEACON);
    bool is_probe_res = (frame_type == FRAME_TYPE_MGMT && frame_subtype == FRAME_SUBTYPE_PROBE_RES);

    if (is_beacon || is_probe_res) {
        // Tagged params start at offset: fixed header (24 bytes) + 12 bytes fixed body (beacon interval etc.)
        int body_offset = sizeof(wifi_mgmt_hdr_t) + 12;
        if (body_offset < payload_len) {
            extract_ssid(payload + body_offset, payload_len - body_offset,
                         pkt.ssid, &pkt.has_ssid);
        }
    }

    // ── Forward to registered detection handler ──
    if (_user_handler) {
        _user_handler(&pkt);
    }
}

// ─────────────────────────────────────────────
//  Public API implementations
// ─────────────────────────────────────────────
void sniffer_init(uint8_t channel) {
    _channel = channel;
    _packet_count = 0;

    // Put Wi-Fi in station mode — required before promiscuous
    WiFi.mode(WIFI_STA);
    WiFi.disconnect();

    esp_wifi_set_promiscuous(true);
    esp_wifi_set_promiscuous_rx_cb(promiscuous_rx_cb);

    // Filter: capture management frames only (change to WIFI_PROMIS_FILTER_MASK_ALL for everything)
    wifi_promiscuous_filter_t filter = {
        .filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT
    };
    esp_wifi_set_promiscuous_filter(&filter);

    sniffer_set_channel(channel);

    Serial.printf("[SNIFFER] Started on channel %d\n", _channel);
}

void sniffer_set_channel(uint8_t channel) {
    if (channel < 1 || channel > 14) return;
    _channel = channel;
    esp_wifi_set_channel(channel, WIFI_SECOND_CHAN_NONE);
}

void sniffer_stop() {
    esp_wifi_set_promiscuous(false);
    Serial.println("[SNIFFER] Stopped.");
}

void sniffer_register_handler(packet_handler_t handler) {
    _user_handler = handler;
}

uint32_t sniffer_get_packet_count() {
    return _packet_count;
}
