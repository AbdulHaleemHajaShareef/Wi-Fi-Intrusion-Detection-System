
/*
 * display.cpp
 *
 * SSD1306 OLED driver — shows live attack information.
 *
 * Wiring (I2C):
 *   SDA → GPIO 21
 *   SCL → GPIO 22
 *   VCC → 3.3 V
 *   GND → GND
 *
 * Required libraries (install via Arduino Library Manager):
 *   - "Adafruit SSD1306"
 *   - "Adafruit GFX Library"
 */

#include "display.h"
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

#define SCREEN_WIDTH  128
#define SCREEN_HEIGHT  64

static Adafruit_SSD1306 _oled(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, -1);

// Index of the event currently shown (cycles through event_log)
static int      _display_idx   = 0;
static uint32_t _last_rotate   = 0;
static bool     _oled_ok       = false;

// ─────────────────────────────────────────────
//  Private: draw the idle / statistics screen
// ─────────────────────────────────────────────
static void draw_idle(uint8_t ch) {
    _oled.clearDisplay();
    _oled.setTextColor(SSD1306_WHITE);

    // ── Header bar ──
    _oled.fillRect(0, 0, SCREEN_WIDTH, 10, SSD1306_WHITE);
    _oled.setTextSize(1);
    _oled.setTextColor(SSD1306_BLACK);
    _oled.setCursor(2, 1);
    _oled.print(F("WiFi IDS - MONITORING"));
    _oled.setTextColor(SSD1306_WHITE);

    // ── Body ──
    _oled.setCursor(0, 14);
    _oled.setTextSize(1);
    _oled.printf("Channel : %d", ch);
    _oled.setCursor(0, 26);
    _oled.printf("Events  : %d", event_log_count());
    _oled.setCursor(0, 38);
    _oled.print(F("Status  : OK"));
    _oled.setCursor(0, 52);
    _oled.print(F("No attacks detected"));

    _oled.display();
}

// ─────────────────────────────────────────────
//  Private: draw a single event card
// ─────────────────────────────────────────────
static void draw_event(const event_record_t *ev, int idx, int total, uint8_t ch) {
    _oled.clearDisplay();
    _oled.setTextColor(SSD1306_WHITE);

    // ── Header bar ──
    _oled.fillRect(0, 0, SCREEN_WIDTH, 10, SSD1306_WHITE);
    _oled.setTextSize(1);
    _oled.setTextColor(SSD1306_BLACK);
    _oled.setCursor(2, 1);
    _oled.printf("IDS ALERT  [%d/%d]", idx + 1, total);
    _oled.setTextColor(SSD1306_WHITE);

    // ── Attack type (large) ──
    _oled.setTextSize(1);
    _oled.setCursor(0, 13);
    _oled.print(attack_type_str(ev->attack_type));

    // ── Severity ──
    _oled.setCursor(70, 13);
    _oled.printf("SEV:%s", severity_str(ev->severity));

    // ── Divider ──
    _oled.drawFastHLine(0, 23, SCREEN_WIDTH, SSD1306_WHITE);

    // ── MAC address ──
    _oled.setCursor(0, 26);
    _oled.setTextSize(1);
    _oled.print(F("MAC:"));
    // Shorten to last 3 octets to fit screen: XX:XX:XX
    const char *mac = ev->src_mac;
    if (strlen(mac) >= 17) {
        _oled.print(mac + 9);   // print from 4th octet onward
    } else {
        _oled.print(mac);
    }

    // ── Channel ──
    _oled.setCursor(96, 26);
    _oled.printf("CH%d", ch);

    // ── Uptime timestamp ──
    uint32_t secs  = ev->timestamp_ms / 1000;
    _oled.setCursor(0, 38);
    _oled.printf("Time: %02lu:%02lu:%02lu",
                 (unsigned long)(secs / 3600),
                 (unsigned long)((secs % 3600) / 60),
                 (unsigned long)(secs % 60));

    // ── Details snippet (first 21 chars) ──
    _oled.setCursor(0, 50);
    char snippet[22];
    strncpy(snippet, ev->details, 21);
    snippet[21] = '\0';
    _oled.print(snippet);

    _oled.display();
}

// ─────────────────────────────────────────────
//  Public API
// ─────────────────────────────────────────────
void display_init() {
    Wire.begin(OLED_SDA_PIN, OLED_SCL_PIN);

    if (!_oled.begin(SSD1306_SWITCHCAPVCC, OLED_ADDRESS)) {
        Serial.println("[DISPLAY] ERROR: SSD1306 not found — check wiring and I2C address.");
        _oled_ok = false;
        return;
    }

    _oled_ok = true;
    _oled.clearDisplay();
    _oled.setTextColor(SSD1306_WHITE);
    _oled.setTextSize(1);
    _oled.setCursor(20, 20);
    _oled.print(F("ESP32 Wi-Fi IDS"));
    _oled.setCursor(30, 35);
    _oled.print(F("Initializing..."));
    _oled.display();
    Serial.println("[DISPLAY] OLED ready.");
}

void display_update(uint8_t current_channel) {
    if (!_oled_ok) return;

    uint32_t now   = millis();
    int      total = event_log_count();

    if ((now - _last_rotate) < DISPLAY_ROTATE_MS) return;
    _last_rotate = now;

    if (total == 0) {
        draw_idle(current_channel);
        return;
    }

    // Cycle through events
    if (_display_idx >= total) _display_idx = 0;
    const event_record_t *ev = event_log_get(total - 1 - _display_idx); // newest first
    if (ev && ev->valid) {
        draw_event(ev, _display_idx, total, current_channel);
    }
    _display_idx = (_display_idx + 1) % total;
}
