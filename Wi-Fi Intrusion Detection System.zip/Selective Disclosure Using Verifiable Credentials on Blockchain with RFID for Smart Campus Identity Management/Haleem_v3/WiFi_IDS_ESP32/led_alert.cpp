
/*
 * led_alert.cpp
 *
 * Non-blocking RGB LED alert system.
 * Three GPIO pins drive LEDs that indicate current threat severity.
 *
 * Wiring:
 *   GPIO 25 ──[220Ω]── RED_LED_anode    ── GND
 *   GPIO 26 ──[220Ω]── YELLOW_LED_anode ── GND
 *   GPIO 27 ──[220Ω]── GREEN_LED_anode  ── GND
 *
 * Behaviour table:
 *   No events / init : GREEN solid
 *   SEV_LOW          : GREEN blink 1 Hz
 *   SEV_MEDIUM       : YELLOW solid
 *   SEV_HIGH         : RED blink 2 Hz  (250 ms on/off)
 *   SEV_CRITICAL     : RED fast blink 10 Hz (50 ms on/off)
 */

#include "led_alert.h"

// ─────────────────────────────────────────────
//  Internal state
// ─────────────────────────────────────────────
static severity_t _current_sev   = (severity_t)(-1);  // force update on first set
static uint32_t   _blink_last_ms = 0;
static bool       _blink_state   = false;

// Active pin and interval (0 = solid, >0 = blink period in ms)
static int      _active_pin     = LED_GREEN_PIN;
static uint32_t _blink_half_ms  = 0;  // half-period (toggle every N ms), 0 = solid

// ─────────────────────────────────────────────
//  Private: turn all LEDs off
// ─────────────────────────────────────────────
static void all_off() {
    digitalWrite(LED_RED_PIN,    LOW);
    digitalWrite(LED_YELLOW_PIN, LOW);
    digitalWrite(LED_GREEN_PIN,  LOW);
}

// ─────────────────────────────────────────────
//  Public API
// ─────────────────────────────────────────────
void led_alert_init() {
    pinMode(LED_RED_PIN,    OUTPUT);
    pinMode(LED_YELLOW_PIN, OUTPUT);
    pinMode(LED_GREEN_PIN,  OUTPUT);
    all_off();
    // Default: solid green = system running, no threats
    digitalWrite(LED_GREEN_PIN, HIGH);
    _active_pin    = LED_GREEN_PIN;
    _blink_half_ms = 0;  // solid
    _current_sev   = SEV_LOW;  // sentinel to force re-apply
    Serial.println("[LED] Alert system ready.");
}

void led_alert_set(severity_t sev) {
    if (sev == _current_sev) return;  // no change
    _current_sev = sev;

    all_off();
    _blink_state   = true;
    _blink_last_ms = millis();

    switch (sev) {
        case SEV_LOW:
            // GREEN blink ~1 Hz (500 ms half-period)
            _active_pin    = LED_GREEN_PIN;
            _blink_half_ms = 500;
            break;
        case SEV_MEDIUM:
            // YELLOW solid
            _active_pin    = LED_YELLOW_PIN;
            _blink_half_ms = 0;
            digitalWrite(LED_YELLOW_PIN, HIGH);
            break;
        case SEV_HIGH:
            // RED blink 2 Hz (250 ms half-period)
            _active_pin    = LED_RED_PIN;
            _blink_half_ms = 250;
            break;
        case SEV_CRITICAL:
            // RED fast blink 10 Hz (50 ms half-period)
            _active_pin    = LED_RED_PIN;
            _blink_half_ms = 50;
            break;
        default:
            // GREEN solid (idle)
            _active_pin    = LED_GREEN_PIN;
            _blink_half_ms = 0;
            digitalWrite(LED_GREEN_PIN, HIGH);
            break;
    }
}

void led_alert_tick() {
    // Solid mode — nothing to update
    if (_blink_half_ms == 0) return;

    uint32_t now = millis();
    if ((now - _blink_last_ms) >= _blink_half_ms) {
        _blink_last_ms = now;
        _blink_state   = !_blink_state;
        digitalWrite(_active_pin, _blink_state ? HIGH : LOW);
    }
}
