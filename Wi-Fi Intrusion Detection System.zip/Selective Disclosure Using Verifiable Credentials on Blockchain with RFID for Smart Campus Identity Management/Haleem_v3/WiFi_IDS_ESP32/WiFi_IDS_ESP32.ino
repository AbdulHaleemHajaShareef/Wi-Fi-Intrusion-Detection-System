
/*
 * WiFi_IDS_ESP32.ino  —  v3.0  (Final Hardware Build)
 * Smart Wi-Fi Intrusion Detection System
 *
 * ── Hardware used ──────────────────────────────────────────
 *  ESP32 WROOM-32 (38-pin)
 *  OLED SSD1306 0.96" I2C        SDA=GPIO21, SCL=GPIO22
 *  RGB LED (Common Cathode)      R=GPIO25,  G=GPIO27,  B=GPIO26
 *  220 ohm resistors x3          one per RGB LED leg
 *  DFPlayer Mini + 8GB MicroSD   RX=GPIO17, TX=GPIO16  (UART2)
 *  Push Button (tactile switch)  GPIO33 + INPUT_PULLUP (no resistor needed)
 *
 * ── What each component does ───────────────────────────────
 *  OLED       -> shows live channel, event count, attack details
 *  RGB LED    -> GREEN=safe  YELLOW=medium  RED blink=high/critical
 *  DFPlayer   -> plays MP3 alarm sound from MicroSD on attack detected
 *  Push Button-> press to acknowledge + clear all current alerts
 *
 * ── MicroSD card setup (FAT32) ─────────────────────────────
 *  Create folder /01/ on the card and put these files inside:
 *    001.mp3  (soft beep  - LOW alert)
 *    002.mp3  (two beeps  - MEDIUM alert)
 *    003.mp3  (alarm tone - HIGH alert)
 *    004.mp3  (loud siren - CRITICAL alert)
 *
 * ── Architecture ───────────────────────────────────────────
 *  Wi-Fi sniffer (promiscuous) → deauth_detector
 *                               → rogue_ap_detector
 *                               → event_log (ring buffer, 30 events)
 *                               → correlation_engine (detects attack chains)
 *                               → OLED / RGB LED / DFPlayer / Button
 */

// ── Core ──────────────────────────────────────────────────
#include "sniffer.h"
// ── Detection ─────────────────────────────────────────────
#include "deauth_detector.h"
#include "rogue_ap_detector.h"
#include "correlation_engine.h"
// ── Logging ───────────────────────────────────────────────
#include "event_log.h"
// ── Hardware output ───────────────────────────────────────
#include "display.h"
#include "led_alert.h"
#include "audio_alert.h"
#include "push_button.h"

// ─────────────────────────────────────────────
//  Config
// ─────────────────────────────────────────────
#define START_CHANNEL    1
#define MAX_CHANNEL      13
#define CHANNEL_HOP_MS   500    // switch channel every 500 ms
#define DEAUTH_TICK_MS   1000   // expire stale deauth entries every 1 s

// ─────────────────────────────────────────────
//  Helper: find highest severity across all events
// ─────────────────────────────────────────────
static severity_t max_event_severity() {
    severity_t max_sev = (severity_t)(-1);
    int total = event_log_count();
    for (int i = 0; i < total; i++) {
        const event_record_t *e = event_log_get(i);
        if (e && e->valid && e->severity > max_sev)
            max_sev = e->severity;
    }
    return (max_sev == (severity_t)(-1)) ? SEV_LOW : max_sev;
}

// ─────────────────────────────────────────────
//  Master packet dispatcher
//  Called by sniffer for every captured frame
// ─────────────────────────────────────────────
void on_packet(const packet_info_t *pkt) {
    int events_before = event_log_count();

    deauth_detector_process(pkt);
    rogue_ap_detector_process(pkt);

    if (event_log_count() > events_before) {
        correlation_engine_update();
        severity_t sev = max_event_severity();
        led_alert_set(sev);
        audio_alert_trigger(sev);   // play MP3 alarm on DFPlayer
    }
}

// ─────────────────────────────────────────────
//  setup()
// ─────────────────────────────────────────────
void setup() {
    Serial.begin(115200);
    delay(500);
    Serial.println(F("\n\n========== ESP32 Wi-Fi IDS v3.0 =========="));

    // 1. Init logging
    event_log_init();

    // 2. Init detection modules
    deauth_detector_init();
    rogue_ap_detector_init();
    correlation_engine_init();

    // 3. Init all hardware
    display_init();
    led_alert_init();
    audio_alert_init();    // DFPlayer Mini
    push_button_init();    // Acknowledge button

    // 4. Start sniffer
    sniffer_register_handler(on_packet);
    sniffer_init(START_CHANNEL);

    Serial.println(F("[MAIN] System ready -- sniffing all channels."));
    Serial.println(F("[MAIN] Press button to acknowledge and clear alerts."));
}

// ─────────────────────────────────────────────
//  loop()
// ─────────────────────────────────────────────
static uint8_t  _current_channel = START_CHANNEL;
static uint32_t _last_hop_ms     = 0;
static uint32_t _last_tick_ms    = 0;

void loop() {
    uint32_t now = millis();

    // ── Channel hopping ──────────────────────
    if ((now - _last_hop_ms) >= CHANNEL_HOP_MS) {
        _last_hop_ms     = now;
        _current_channel = (_current_channel % MAX_CHANNEL) + 1;
        sniffer_set_channel(_current_channel);
    }

    // ── Expire stale deauth entries + heartbeat ──
    if ((now - _last_tick_ms) >= DEAUTH_TICK_MS) {
        _last_tick_ms = now;
        deauth_detector_tick();
        Serial.printf("[MAIN] pkts=%lu events=%d ch=%d\n",
                      sniffer_get_packet_count(),
                      event_log_count(),
                      _current_channel);
    }

    // ── Push button: acknowledge and clear alerts ──
    push_button_tick();
    if (push_button_was_pressed()) {
        event_log_clear();                      // clear all logged events
        led_alert_set(SEV_LOW);                 // reset LED to green
        Serial.println(F("[MAIN] Alerts acknowledged and cleared."));
    }

    // ── Hardware output (non-blocking) ───────
    display_update(_current_channel);
    led_alert_tick();
    audio_alert_tick();    // drains DFPlayer serial replies
}
