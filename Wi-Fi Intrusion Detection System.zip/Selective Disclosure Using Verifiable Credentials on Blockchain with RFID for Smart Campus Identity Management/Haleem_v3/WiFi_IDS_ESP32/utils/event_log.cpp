
#include "event_log.h"
#include "../sniffer/sniffer.h"  // for mac_to_str

static event_record_t _log[MAX_EVENTS];
static int _head = 0;   // next write position (ring buffer)
static int _count = 0;

void event_log_init() {
    memset(_log, 0, sizeof(_log));
    _head  = 0;
    _count = 0;
}

void event_log_add(attack_type_t type, severity_t sev,
                   const uint8_t *src_mac, const char *details) {
    event_record_t *rec = &_log[_head];
    rec->timestamp_ms = millis();
    rec->attack_type  = type;
    rec->severity     = sev;
    rec->valid        = true;
    mac_to_str(src_mac, rec->src_mac);
    strncpy(rec->details, details, sizeof(rec->details) - 1);
    rec->details[sizeof(rec->details) - 1] = '\0';

    Serial.printf("[EVENT] %s | %s | MAC:%s | %s\n",
                  attack_type_str(type), severity_str(sev),
                  rec->src_mac, rec->details);

    _head = (_head + 1) % MAX_EVENTS;
    if (_count < MAX_EVENTS) _count++;
}

int event_log_count() { return _count; }

// returns in insertion order (oldest first)
const event_record_t* event_log_get(int index) {
    if (index < 0 || index >= _count) return nullptr;
    int real_idx;
    if (_count < MAX_EVENTS) {
        real_idx = index;
    } else {
        real_idx = (_head + index) % MAX_EVENTS;
    }
    return &_log[real_idx];
}

void event_log_clear() {
    memset(_log, 0, sizeof(_log));
    _head  = 0;
    _count = 0;
}

const char* severity_str(severity_t s) {
    switch (s) {
        case SEV_LOW:      return "LOW";
        case SEV_MEDIUM:   return "MEDIUM";
        case SEV_HIGH:     return "HIGH";
        case SEV_CRITICAL: return "CRITICAL";
        default:           return "UNKNOWN";
    }
}

const char* attack_type_str(attack_type_t t) {
    switch (t) {
        case ATK_DEAUTH:      return "DEAUTH";
        case ATK_ROGUE_AP:   return "ROGUE_AP";
        case ATK_COORDINATED: return "COORDINATED";
        default:              return "UNKNOWN";
    }
}
