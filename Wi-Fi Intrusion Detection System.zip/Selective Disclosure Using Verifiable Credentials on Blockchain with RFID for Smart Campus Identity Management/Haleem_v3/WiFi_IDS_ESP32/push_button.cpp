/*
 * push_button.cpp
 *
 * Debounced push button — non-blocking, checked every loop().
 * Detects a falling edge (HIGH → LOW when pressed, since INPUT_PULLUP).
 */

#include "push_button.h"

static bool     _last_state     = HIGH;
static bool     _pressed_flag   = false;
static uint32_t _last_change_ms = 0;

void push_button_init() {
    pinMode(BUTTON_PIN, INPUT_PULLUP);
    Serial.println("[BTN] Push button ready on GPIO " + String(BUTTON_PIN) + ".");
}

void push_button_tick() {
    bool current = digitalRead(BUTTON_PIN);
    uint32_t now = millis();

    // Detect a stable falling edge (HIGH -> LOW) after debounce period
    if (current != _last_state) {
        _last_change_ms = now;
        _last_state = current;
    }

    if ((now - _last_change_ms) >= BUTTON_DEBOUNCE_MS) {
        // State is stable — if LOW (pressed) and not already flagged
        if (current == LOW && !_pressed_flag) {
            _pressed_flag = true;
            Serial.println("[BTN] Button pressed — acknowledging alerts.");
        }
    }
}

bool push_button_was_pressed() {
    if (_pressed_flag) {
        _pressed_flag = false;
        return true;
    }
    return false;
}
