
#ifndef DISPLAY_H
#define DISPLAY_H

#include <Arduino.h>
#include "../utils/event_log.h"

// I2C pins (default ESP32: SDA=21, SCL=22 — change if your wiring differs)
#define OLED_SDA_PIN  21
#define OLED_SCL_PIN  22
#define OLED_ADDRESS  0x3C   // Most SSD1306 modules use 0x3C; try 0x3D if blank

// How long each event is shown before rotating to the next
#define DISPLAY_ROTATE_MS  3000

void display_init();
void display_update(uint8_t current_channel);  // call from loop()

#endif // DISPLAY_H
