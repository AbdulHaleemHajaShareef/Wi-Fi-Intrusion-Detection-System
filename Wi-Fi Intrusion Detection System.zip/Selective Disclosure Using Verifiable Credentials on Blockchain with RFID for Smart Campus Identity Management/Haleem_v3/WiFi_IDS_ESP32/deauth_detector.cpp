
#include "deauth_detector.h"

// ─────────────────────────────────────────
//  Per-MAC tracking entry
// ─────────────────────────────────────────
typedef struct {
    uint8_t  mac[6];
    uint16_t count;           // packets in current window
    uint32_t window_start_ms;
    bool     active;
} deauth_entry_t;

static deauth_entry_t _table[DEAUTH_MAX_TRACKED_MACS];

// ─────────────────────────────────────────
//  Broadcast MAC check
// ─────────────────────────────────────────
static bool is_broadcast(const uint8_t *mac) {
    return mac[0] == 0xFF && mac[1] == 0xFF && mac[2] == 0xFF &&
           mac[3] == 0xFF && mac[4] == 0xFF && mac[5] == 0xFF;
}

// ─────────────────────────────────────────
//  Find or allocate a tracking slot
// ─────────────────────────────────────────
static deauth_entry_t* find_or_create(const uint8_t *mac) {
    int   free_slot = -1;
    for (int i = 0; i < DEAUTH_MAX_TRACKED_MACS; i++) {
        if (_table[i].active && memcmp(_table[i].mac, mac, 6) == 0)
            return &_table[i];
        if (!_table[i].active && free_slot == -1)
            free_slot = i;
    }
    if (free_slot == -1) return nullptr;   // table full — drop oldest TODO
    memcpy(_table[free_slot].mac, mac, 6);
    _table[free_slot].count          = 0;
    _table[free_slot].window_start_ms = millis();
    _table[free_slot].active         = true;
    return &_table[free_slot];
}

// ─────────────────────────────────────────
//  Classify based on count in window
// ─────────────────────────────────────────
static severity_t classify(uint16_t count, bool is_targeted_broadcast) {
    if (count >= DEAUTH_CRITICAL_THRESHOLD && !is_targeted_broadcast)
        return SEV_CRITICAL;     // high-rate targeted burst
    if (count >= DEAUTH_HIGH_THRESHOLD)
        return SEV_HIGH;
    if (count >= DEAUTH_MEDIUM_THRESHOLD)
        return SEV_MEDIUM;
    return SEV_LOW;
}

// ─────────────────────────────────────────
//  Public
// ─────────────────────────────────────────
void deauth_detector_init() {
    memset(_table, 0, sizeof(_table));
    Serial.println("[DEAUTH] Detector initialized.");
}

void deauth_detector_process(const packet_info_t *pkt) {
    // Only care about Deauthentication management frames
    if (pkt->frame_type != FRAME_TYPE_MGMT) return;
    if (pkt->frame_subtype != FRAME_SUBTYPE_DEAUTH) return;

    deauth_entry_t *entry = find_or_create(pkt->src_mac);
    if (!entry) return;

    uint32_t now = millis();
    // Reset window if expired
    if ((now - entry->window_start_ms) > DEAUTH_TIME_WINDOW_MS) {
        entry->count           = 0;
        entry->window_start_ms = now;
    }

    entry->count++;

    // Only log an event when crossing a threshold boundary
    bool broadcast_dst = is_broadcast(pkt->dst_mac);
    severity_t sev = classify(entry->count, !broadcast_dst);

    // Fire event at each threshold boundary exactly once
    bool at_boundary = (entry->count == DEAUTH_LOW_THRESHOLD)    ||
                       (entry->count == DEAUTH_MEDIUM_THRESHOLD)  ||
                       (entry->count == DEAUTH_HIGH_THRESHOLD)    ||
                       (entry->count == DEAUTH_CRITICAL_THRESHOLD);
    if (!at_boundary) return;

    char details[80];
    snprintf(details, sizeof(details),
             "count=%d window=%dms bcast=%s RSSI=%d",
             entry->count, DEAUTH_TIME_WINDOW_MS,
             broadcast_dst ? "yes" : "no", pkt->rssi);

    event_log_add(ATK_DEAUTH, sev, pkt->src_mac, details);
}

// Expire stale table entries — call every second from loop()
void deauth_detector_tick() {
    uint32_t now = millis();
    for (int i = 0; i < DEAUTH_MAX_TRACKED_MACS; i++) {
        if (!_table[i].active) continue;
        if ((now - _table[i].window_start_ms) > DEAUTH_TIME_WINDOW_MS * 3) {
            _table[i].active = false;
        }
    }
}
