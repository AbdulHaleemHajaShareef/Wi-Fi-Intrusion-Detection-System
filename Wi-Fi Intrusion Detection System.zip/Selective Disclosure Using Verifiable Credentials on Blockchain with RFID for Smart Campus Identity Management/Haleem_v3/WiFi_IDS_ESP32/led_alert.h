
#ifndef LED_ALERT_H
#define LED_ALERT_H

#include <Arduino.h>
#include "event_log.h"

// ── GPIO pin assignments ──────────────────────
// Connect each pin via a 220Ω resistor to the LED anode; cathode to GND.
#define LED_RED_PIN     25
#define LED_YELLOW_PIN  26
#define LED_GREEN_PIN   27

void led_alert_init();
void led_alert_set(severity_t sev);   // call whenever the max severity changes
void led_alert_tick();                // call every loop() iteration (non-blocking)

#endif // LED_ALERT_H
