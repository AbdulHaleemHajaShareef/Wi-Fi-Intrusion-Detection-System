/*
 * audio_alert.cpp
 *
 * Controls DFPlayer Mini to play MP3 alert sounds.
 * Uses HardwareSerial2 (UART2) on ESP32.
 *
 * Track mapping (files must be on MicroSD in /01/ folder):
 *   001.mp3  -> SEV_LOW      (1 soft beep sound)
 *   002.mp3  -> SEV_MEDIUM   (2 beep sound)
 *   003.mp3  -> SEV_HIGH     (urgent alarm)
 *   004.mp3  -> SEV_CRITICAL (loud continuous alarm)
 *
 * Cooldown: won't play a new sound until the previous one
 * is likely finished (AUDIO_COOLDOWN_MS).
 */

#include "audio_alert.h"
#include <HardwareSerial.h>

#define AUDIO_COOLDOWN_MS   3000   // minimum ms between plays
#define DFPLAYER_VOLUME     25     // 0-30

static HardwareSerial _dfSerial(2);   // UART2
static uint32_t _last_play_ms = 0;
static bool     _ready        = false;

// ─────────────────────────────────────────────
//  DFPlayer Mini raw command builder
//  Sends the 10-byte serial command protocol
// ─────────────────────────────────────────────
static void dfplayer_send(uint8_t cmd, uint8_t param1, uint8_t param2) {
    uint8_t buf[10];
    buf[0] = 0x7E;   // start byte
    buf[1] = 0xFF;   // version
    buf[2] = 0x06;   // length
    buf[3] = cmd;
    buf[4] = 0x00;   // no feedback
    buf[5] = param1;
    buf[6] = param2;
    // Checksum: negate sum of bytes 1..6
    int16_t checksum = -(buf[1] + buf[2] + buf[3] + buf[4] + buf[5] + buf[6]);
    buf[7] = (checksum >> 8) & 0xFF;
    buf[8] = checksum & 0xFF;
    buf[9] = 0xEF;   // end byte
    _dfSerial.write(buf, 10);
}

// ─────────────────────────────────────────────
//  Public API
// ─────────────────────────────────────────────
void audio_alert_init() {
    _dfSerial.begin(9600, SERIAL_8N1, DFPLAYER_RX_PIN, DFPLAYER_TX_PIN);
    delay(1000);   // DFPlayer needs ~1s to boot

    dfplayer_send(0x3F, 0x00, 0x00);   // query init (optional, wakes module)
    delay(200);
    dfplayer_send(0x06, 0x00, DFPLAYER_VOLUME);   // set volume
    delay(100);

    _ready = true;
    Serial.println("[AUDIO] DFPlayer Mini ready.");
}

void audio_alert_trigger(severity_t sev) {
    if (!_ready) return;

    uint32_t now = millis();
    if ((now - _last_play_ms) < AUDIO_COOLDOWN_MS) return;   // still cooling down

    // Track number matches severity + 1 (1-indexed)
    uint8_t track = (uint8_t)sev + 1;   // 1=LOW, 2=MEDIUM, 3=HIGH, 4=CRITICAL
    if (track < 1) track = 1;
    if (track > 4) track = 4;

    dfplayer_send(0x0F, 0x01, track);   // play file in folder 01, track N
    _last_play_ms = now;

    Serial.printf("[AUDIO] Playing track %d for severity %d\n", track, (int)sev);
}

void audio_alert_tick() {
    // Drain any bytes DFPlayer sends back (status replies) to keep UART buffer clear
    while (_dfSerial.available()) {
        _dfSerial.read();
    }
}
