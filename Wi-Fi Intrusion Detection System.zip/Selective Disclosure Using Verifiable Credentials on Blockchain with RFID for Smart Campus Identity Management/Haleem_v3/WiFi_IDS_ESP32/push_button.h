#ifndef PUSH_BUTTON_H
#define PUSH_BUTTON_H

#include <Arduino.h>

/*
 * push_button.h
 *
 * Debounced push button to acknowledge/clear all active alerts.
 * Pressing the button:
 *   - Clears the event log
 *   - Resets the RGB LED back to solid GREEN (safe state)
 *   - Prints acknowledgement to Serial
 *
 * Wiring:
 *   ESP32 GPIO 34 ──── Button leg 1
 *   GND           ──── Button leg 2
 *   (uses INPUT_PULLUP internally — no external resistor needed)
 *
 * Note: GPIO 34 is input-only on ESP32 (no internal pullup).
 * So wire a 10kΩ resistor from GPIO 34 to 3.3V (external pull-up),
 * and button connects GPIO 34 to GND.
 * OR use GPIO 33 which supports INPUT_PULLUP (saves the resistor).
 */

#define BUTTON_PIN        33    // GPIO 33 supports INPUT_PULLUP
#define BUTTON_DEBOUNCE_MS  50  // debounce time

void push_button_init();
void push_button_tick();   // call every loop() — checks for press

// Returns true once per press (cleared after read)
bool push_button_was_pressed();

#endif // PUSH_BUTTON_H
