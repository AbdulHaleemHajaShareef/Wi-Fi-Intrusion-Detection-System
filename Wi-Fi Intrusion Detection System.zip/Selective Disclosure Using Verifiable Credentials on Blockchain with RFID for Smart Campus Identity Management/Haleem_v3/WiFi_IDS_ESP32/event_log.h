
#ifndef EVENT_LOG_H
#define EVENT_LOG_H

#include <Arduino.h>

// ─────────────────────────────────────────
//  Severity levels
// ─────────────────────────────────────────
typedef enum {
    SEV_LOW      = 0,
    SEV_MEDIUM   = 1,
    SEV_HIGH     = 2,
    SEV_CRITICAL = 3
} severity_t;

// ─────────────────────────────────────────
//  Attack types
// ─────────────────────────────────────────
typedef enum {
    ATK_DEAUTH       = 0,
    ATK_ROGUE_AP     = 1,
    ATK_COORDINATED  = 2   // Correlation engine: chained attack
} attack_type_t;

// ─────────────────────────────────────────
//  Single event record
// ─────────────────────────────────────────
#define MAX_EVENTS 30

typedef struct {
    uint32_t     timestamp_ms;
    attack_type_t attack_type;
    severity_t   severity;
    char         src_mac[18];       // "AA:BB:CC:DD:EE:FF"
    char         details[80];       // human-readable extra info
    bool         valid;
} event_record_t;

// ─────────────────────────────────────────
//  Public API
// ─────────────────────────────────────────
void     event_log_init();
void     event_log_add(attack_type_t type, severity_t sev,
                       const uint8_t *src_mac, const char *details);
int      event_log_count();
const event_record_t* event_log_get(int index);   // oldest-first index
void     event_log_clear();

// Human-readable helpers
const char* severity_str(severity_t s);
const char* attack_type_str(attack_type_t t);

#endif // EVENT_LOG_H
