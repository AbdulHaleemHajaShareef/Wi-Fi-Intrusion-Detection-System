#ifndef AUDIO_ALERT_H
#define AUDIO_ALERT_H

#include <Arduino.h>
#include "event_log.h"

/*
 * audio_alert.h
 *
 * Drives a DFPlayer Mini MP3 module via UART to play
 * alert sounds when attacks are detected.
 *
 * Wiring:
 *   ESP32 GPIO 16 (RX2) ──[1kΩ resistor]──► DFPlayer RX
 *   ESP32 GPIO 17 (TX2) ──────────────────► DFPlayer TX
 *   DFPlayer VCC ──────────────────────────► ESP32 3.3V  (or 5V if module needs it)
 *   DFPlayer GND ──────────────────────────► ESP32 GND
 *   DFPlayer SPK1 ─────────────────────────► Speaker +
 *   DFPlayer SPK2 ─────────────────────────► Speaker -
 *
 * MicroSD card folder structure (FAT32 format):
 *   /01/001.mp3   <- SEV_LOW    alert sound
 *   /01/002.mp3   <- SEV_MEDIUM alert sound
 *   /01/003.mp3   <- SEV_HIGH   alert sound
 *   /01/004.mp3   <- SEV_CRITICAL alert sound
 *
 * Use any short beep/alarm MP3 files (1-3 seconds each).
 */

#define DFPLAYER_RX_PIN   16   // ESP32 RX2 -> DFPlayer TX
#define DFPLAYER_TX_PIN   17   // ESP32 TX2 -> DFPlayer RX

void audio_alert_init();
void audio_alert_trigger(severity_t sev);   // play track for severity level
void audio_alert_tick();                     // call every loop() for cooldown timing

#endif // AUDIO_ALERT_H
