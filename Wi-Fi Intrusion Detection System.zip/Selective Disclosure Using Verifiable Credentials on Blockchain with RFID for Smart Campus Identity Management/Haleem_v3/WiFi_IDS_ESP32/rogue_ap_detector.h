
#ifndef ROGUE_AP_DETECTOR_H
#define ROGUE_AP_DETECTOR_H

#include <Arduino.h>
#include "sniffer.h"
#include "event_log.h"

// How many unique SSIDs we track in memory
#define MAX_KNOWN_APS  40

void rogue_ap_detector_init();
void rogue_ap_detector_process(const packet_info_t *pkt);

#endif
