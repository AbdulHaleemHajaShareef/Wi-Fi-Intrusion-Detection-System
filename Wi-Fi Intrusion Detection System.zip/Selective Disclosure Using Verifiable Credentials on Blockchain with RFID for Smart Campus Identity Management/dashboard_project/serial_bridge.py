import os
import time
import json
import threading
import serial
import serial.tools.list_ports
from flask import Flask, jsonify, request
from flask_cors import CORS

# ==========================================
# CONFIGURATION
# ==========================================
BAUD_RATE = 115200
API_PORT = 5000

app = Flask(__name__)
# Enable CORS for all routes so the dashboard.html can fetch data easily
CORS(app)

# Global state to hold the latest data from the ESP32
# Structure matches the dashboard.html frontend requirements
latest_state = {
    "networks": [],
    "alerts": []
}

state_lock = threading.Lock()

# ==========================================
# SERIAL PORT AUTO-DETECTION
# ==========================================
def find_esp32_port():
    """Attempts to find the connected ESP32 serial port."""
    ports = serial.tools.list_ports.comports()
    for port in ports:
        # ESP32 usually shows up with CP210x or CH340 or simply USB Serial
        if 'CP210' in port.description or 'CH340' in port.description or 'USB' in port.description:
            return port.device
    
    # Fallback to the first available port if exact match isn't found
    if ports:
        return sorted(ports)[0].device
    return None

# ==========================================
# SERIAL READER THREAD
# ==========================================
def serial_reader_thread():
    port = find_esp32_port()
    if not port:
        print("[ERROR] No serial ports found. Is the ESP32 plugged in?")
        print("[INFO] Starting Flask API in MOCK mode (waiting for hardware)...")
        # In a real scenario, you could loop and wait for connection here.
        return

    print(f"[INFO] Connecting to ESP32 on {port} at {BAUD_RATE} baud...")
    try:
        ser = serial.Serial(port, BAUD_RATE, timeout=2)
        print("[SUCCESS] Serial connected. Waiting for JSON stream...")
    except Exception as e:
        print(f"[ERROR] Failed to open port {port}: {e}")
        return

    while True:
        try:
            line = ser.readline().decode('utf-8', errors='ignore').strip()
            
            # ESP32 might send debug print statements alongside JSON
            # We look for lines starting with { to parse JSON payloads
            if line.startswith('{') and line.endswith('}'):
                try:
                    payload = json.loads(line)
                    
                    # Update global state safely
                    with state_lock:
                        if "networks" in payload:
                            latest_state["networks"] = payload["networks"]
                        if "alerts" in payload:
                            latest_state["alerts"] = payload["alerts"]
                            
                    print(f"[RECV] Extracted JSON state. Networks: {len(latest_state['networks'])}, Alerts: {len(latest_state['alerts'])}")
                    
                except json.JSONDecodeError:
                    print(f"[WARN] Failed to parse JSON: {line}")
            elif line:
                # Print non-JSON ESP32 debug messages to the console
                print(f"[ESP32 RAW] {line}")
                
        except serial.SerialException as e:
            print(f"[ERROR] Serial connection lost: {e}")
            break
        except Exception as e:
            print(f"[ERROR] Reader thread issue: {e}")
            time.sleep(1)

# ==========================================
# FLASK API ENDPOINTS
# ==========================================
@app.route('/api/dashboard_state', methods=['GET'])
def get_dashboard_state():
    """Returns the most recent Wi-Fi scan and alert state."""
    with state_lock:
        return jsonify(latest_state)

@app.route('/api/scan', methods=['POST'])
def post_scan():
    """Optional endpoint if ESP32 sends data via HTTP POST instead of Serial."""
    data = request.json
    with state_lock:
        if "networks" in data:
            latest_state["networks"] = data["networks"]
        if "alerts" in data:
            latest_state["alerts"] = data["alerts"]
    return jsonify({"status": "success", "msg": "State updated"}), 200

# ==========================================
# MAIN EXECUTION
# ==========================================
if __name__ == '__main__':
    print(r"""
  __  __       _ _   _      _____ _                  
 |  \/  |     | | | (_)    / ____| |                 
 | \  / |_   _| | |_ _ ___| (___ | |_ __ _  __ _  ___
 | |\/| | | | | | __| / __|\___ \| __/ _` |/ _` |/ _ \
 | |  | | |_| | | |_| \__ \____) | || (_| | (_| |  __/
 |_|  |_|\__,_|_|\__|_|___/_____/ \__\__,_|\__, |\___|
    Wi-Fi IDS Serial Bridge & Dashboard API __/ |    
                                           |___/     
    """)
    
    # Start the serial reader background thread
    t = threading.Thread(target=serial_reader_thread, daemon=True)
    t.start()
    
    # Start Flask API (blocking)
    print(f"[INFO] Hosting SOC Dashboard API on http://localhost:{API_PORT}/api/dashboard_state")
    app.run(host='0.0.0.0', port=API_PORT, debug=False, use_reloader=False)
