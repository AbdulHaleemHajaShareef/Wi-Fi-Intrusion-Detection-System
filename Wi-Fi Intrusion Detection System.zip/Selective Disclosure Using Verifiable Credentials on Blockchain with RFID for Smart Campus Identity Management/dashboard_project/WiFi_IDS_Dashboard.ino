#include <WiFi.h>
#include <esp_wifi.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// ==========================================
// CONFIGURATION
// ==========================================
#define SERIAL_BAUD 115200
#define REPORT_INTERVAL_MS 2000
#define HOP_INTERVAL_MS 500
#define DEAUTH_THRESHOLD 15 // pkts per interval to trigger alert

// HARDWARE PINS (Configured for Demo)
#define LED_GREEN 23    // SAFE
#define LED_YELLOW 19   // WARNING
#define LED_RED 18      // CRITICAL
#define BTN_ACK 5       // Push button

// OLED CONFIG
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// ==========================================
// STATE VARIABLES
// ==========================================
uint8_t current_channel = 1;
uint32_t last_hop_time = 0;
uint32_t last_report_time = 0;

volatile uint32_t deauth_count = 0;
volatile uint32_t probe_count = 0;

enum SystemState { STATUS_SAFE, STATUS_WARNING, STATUS_CRITICAL };
SystemState current_status = STATUS_SAFE;

// Track the biggest attacking MAC (for demo simplification)
uint8_t last_attacker_mac[6] = {0};

// Simple Network Tracking Array
#define MAX_NETWORKS 10
struct Network {
    String ssid;
    String bssid;
    int rssi;
    int channel;
    String encryption;
    bool is_rogue;
    uint32_t last_seen;
};
Network networks[MAX_NETWORKS];
int net_count = 0;

// ==========================================
// HELPER FUNCTIONS
// ==========================================
String macToString(const uint8_t* mac) {
    char buf[18];
    sprintf(buf, "%02X:%02X:%02X:%02X:%02X:%02X", mac[0], mac[1], mac[2], mac[3], mac[4], mac[5]);
    return String(buf);
}

void update_leds(SystemState state) {
    digitalWrite(LED_GREEN, state == STATUS_SAFE);
    digitalWrite(LED_YELLOW, state == STATUS_WARNING);
    digitalWrite(LED_RED, state == STATUS_CRITICAL); // Let loop() blink RED later
}

// ==========================================
// PROMISCUOUS MODE CALLBACK
// ==========================================
void sniffer_callback(void* buf, wifi_promiscuous_pkt_type_t type) {
    wifi_promiscuous_pkt_t* pkt = (wifi_promiscuous_pkt_t*)buf;
    uint8_t* payload = pkt->payload;
    uint16_t length = pkt->rx_ctrl.sig_len;
    if (length < 24) return;

    // Frame Control
    uint8_t frame_control = payload[0];
    uint8_t frame_type = (frame_control & 0x0C) >> 2;
    uint8_t frame_subtype = (frame_control & 0xF0) >> 4;

    // Is it a Management Frame? (Type 0)
    if (frame_type == 0) {
        
        // 1. Deauth / Disassoc check
        if (frame_subtype == 12 || frame_subtype == 10) { 
            deauth_count++;
            // Store attacker/source MAC (bytes 10-15)
            memcpy(last_attacker_mac, payload + 10, 6);
        }
        
        // 2. Beacon checks (for Rogue AP detection & Topography)
        if (frame_subtype == 8) {
            uint8_t* bssid = payload + 16;
            String macStr = macToString(bssid);
            
            // Extract SSID from tags (simplified logic, skipping fixed params)
            uint8_t ssid_len = payload[37];
            if (ssid_len > 0 && ssid_len < 32 && (38 + ssid_len) < length) {
                char ssid_buf[33];
                memcpy(ssid_buf, payload + 38, ssid_len);
                ssid_buf[ssid_len] = 0;
                String ssidStr = String(ssid_buf);
                
                // Extremely simple Rogue check: Identical SSID with a new BSSID
                bool found = false;
                bool is_rogue = false;
                
                for (int i = 0; i < net_count; i++) {
                    if (networks[i].bssid == macStr) {
                        networks[i].rssi = pkt->rx_ctrl.rssi;
                        networks[i].last_seen = millis();
                        found = true;
                        break;
                    }
                    // Rogue check: same name, different MAC
                    if (networks[i].ssid == ssidStr && networks[i].bssid != macStr) {
                        is_rogue = true;
                    }
                }
                
                if (!found && net_count < MAX_NETWORKS) {
                    networks[net_count].ssid = ssidStr;
                    networks[net_count].bssid = macStr;
                    networks[net_count].rssi = pkt->rx_ctrl.rssi;
                    networks[net_count].channel = current_channel;
                    networks[net_count].encryption = "WPA2"; // Simplified
                    networks[net_count].is_rogue = is_rogue;
                    networks[net_count].last_seen = millis();
                    net_count++;
                }
            }
        }
    }
}

// ==========================================
// SETUP
// ==========================================
void setup() {
    Serial.begin(SERIAL_BAUD);
    
    pinMode(LED_GREEN, OUTPUT);
    pinMode(LED_YELLOW, OUTPUT);
    pinMode(LED_RED, OUTPUT);
    pinMode(BTN_ACK, INPUT_PULLUP);
    
    // Test LEDs
    update_leds(STATUS_SAFE);

    // Init OLED
    if (!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
        Serial.println("SSD1306 OLED allocation failed");
    } else {
        display.clearDisplay();
        display.setTextSize(1);
        display.setTextColor(WHITE);
        display.setCursor(0,0);
        display.println("IDS SOC Backend");
        display.println("Initializing...");
        display.display();
        delay(1000);
    }

    // Init Wi-Fi Sniffer
    WiFi.mode(WIFI_MODE_PROMISCUOUS);
    esp_wifi_set_promiscuous(false);
    
    // Set promiscuous filter (catch mgmt frames mostly)
    wifi_promiscuous_filter_t filter;
    filter.filter_mask = WIFI_PROMIS_FILTER_MASK_MGMT | WIFI_PROMIS_FILTER_MASK_CTRL;
    esp_wifi_set_promiscuous_filter(&filter);
    
    esp_wifi_set_promiscuous_rx_cb(&sniffer_callback);
    esp_wifi_set_promiscuous(true);

    last_hop_time = millis();
    last_report_time = millis();
}

// ==========================================
// LOOP
// ==========================================
void loop() {
    uint32_t now = millis();

    // 1. Channel Hopping
    if (now - last_hop_time > HOP_INTERVAL_MS) {
        last_hop_time = now;
        current_channel++;
        if (current_channel > 13) current_channel = 1;
        esp_wifi_set_channel(current_channel, WIFI_SECOND_CHAN_NONE);
    }
    
    // 2. Acknowledge Button
    if (digitalRead(BTN_ACK) == LOW) {
        current_status = STATUS_SAFE;
        deauth_count = 0;
        update_leds(current_status);
        display.clearDisplay();
        display.setCursor(0,0);
        display.println("IDS Active");
        display.println("Alerts Reset.");
        display.display();
        delay(300); // debounce
    }
    
    // 3. Serial JSON Report (API Polling equivalent)
    if (now - last_report_time > REPORT_INTERVAL_MS) {
        last_report_time = now;
        
        // --- Calculate Threat Level ---
        if (deauth_count > DEAUTH_THRESHOLD) {
            current_status = STATUS_CRITICAL;
        } else if (deauth_count > 0) {
            current_status = STATUS_WARNING;
        } else {
            // Check for unacknowledged Rogues
            bool has_rogue = false;
            for(int i=0; i<net_count; i++) if(networks[i].is_rogue) has_rogue = true;
            if (has_rogue) current_status = STATUS_CRITICAL;
        }

        update_leds(current_status);
        
        // --- Update OLED ---
        display.clearDisplay();
        display.setCursor(0,0);
        display.print("CH: "); display.print(current_channel);
        display.print("  Nets: "); display.println(net_count);
        display.drawLine(0, 10, 128, 10, WHITE);
        
        if (current_status == STATUS_CRITICAL) {
            display.setCursor(0, 15);
            display.println(">>> ATTACK DETECTED <<<");
            display.print("Deauth rate: "); display.println(deauth_count);
            display.print("MAC:"); display.println(macToString(last_attacker_mac));
        } else if (current_status == STATUS_WARNING) {
            display.setCursor(0, 15);
            display.println("! WARNING !");
            display.print("Suspicious traffic: "); display.println(deauth_count);
        } else {
            display.setCursor(0, 15);
            display.println("Status: SECURE");
            display.println("Scanning frequencies...");
        }
        display.display();

        // --- Build & Dump JSON string to Serial ---
        // Warning: String concatenation logic isn't highly optimal for ESP32 RAM,
        // but it's perfect and readable for a final year university demo
        
        String json = "{";
        
        // Networks Payload
        json += "\"networks\": [";
        for (int i = 0; i < net_count; i++) {
            json += "{\"ssid\":\"" + networks[i].ssid + "\",";
            json += "\"bssid\":\"" + networks[i].bssid + "\",";
            json += "\"rssi\":" + String(networks[i].rssi) + ",";
            json += "\"channel\":" + String(networks[i].channel) + ",";
            json += "\"encryption\":\"" + networks[i].encryption + "\",";
            json += "\"is_rogue\":" + String(networks[i].is_rogue ? "true" : "false") + "}";
            if (i < net_count - 1) json += ",";
        }
        json += "], ";
        
        // Alerts Payload
        json += "\"alerts\": [";
        bool has_alert = false;
        if (deauth_count > DEAUTH_THRESHOLD) {
            json += "{\"type\":\"Deauth Flood\", \"severity\":\"CRITICAL\", \"target\":\"Broadcast\",";
            json += "\"source\":\"" + macToString(last_attacker_mac) + "\",";
            json += "\"rate\":" + String(deauth_count) + ", \"timestamp\":" + String(millis()) + "}";
            has_alert = true;
        } else if (deauth_count > 0) {
            json += "{\"type\":\"Deauth Probe\", \"severity\":\"MEDIUM\", \"target\":\"Broadcast\",";
            json += "\"source\":\"" + macToString(last_attacker_mac) + "\",";
            json += "\"rate\":" + String(deauth_count) + ", \"timestamp\":" + String(millis()) + "}";
            has_alert = true;
        }
        
        for (int i = 0; i < net_count; i++) {
            if (networks[i].is_rogue) {
                if (has_alert) json += ",";
                json += "{\"type\":\"Rogue AP\", \"severity\":\"CRITICAL\", \"target\":\"" + networks[i].ssid + "\",";
                json += "\"source\":\"" + networks[i].bssid + "\",";
                json += "\"rate\":1, \"timestamp\":" + String(millis()) + "}";
                has_alert = true;
            }
        }
        
        json += "]}";
        
        // Ship the JSON to python
        Serial.println(json);
        
        // Reset counters for next cycle
        deauth_count = 0;
        
        // Blink RED LED if Critical
        if (current_status == STATUS_CRITICAL) {
           digitalWrite(LED_RED, !digitalRead(LED_RED)); 
        }
    }
}
